
import express from "express";
import helmet from "helmet";
import cors from "cors";
import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import { v4 as uuidv4 } from "uuid";

const app = express();
app.use(helmet());
app.use(cors({origin:false}));
app.use(express.json());
app.use(express.static("public"));

const dbPath = process.env.ELECTIONS_DB_PATH || "elections.db";
const db = new Database(dbPath);

function getMesaIdFromKey(req){
  const key = req.headers["x-mesa-key"];
  if(!key) return null;
  const row = db.prepare("SELECT mesa_id FROM mesa_keys WHERE key=?").get(key);
  return row? row.mesa_id : null;
}

// --- API ---

// Mesa login: jurado ingresa código de su mesa y recibe una llave local
app.post("/api/mesa/login",(req,res)=>{
  const {mesa_code} = req.body||{};
  if(!mesa_code) return res.json({ok:false,error:"Falta código"});
  const mesa = db.prepare("SELECT id, code_hash FROM mesas WHERE code=?").get(mesa_code);
  if(!mesa) return res.json({ok:false,error:"Código inválido"});
  const mesa_key = uuidv4();
  db.prepare("INSERT INTO mesa_keys(key, mesa_id, created_at) VALUES(?,?,datetime('now'))").run(mesa_key, mesa.id);
  return res.json({ok:true, mesa_key});
});

// Verificar identidad (dni + otp). Devuelve races y opciones aplicables
app.post("/api/voter/verify",(req,res)=>{
  const mesaId = getMesaIdFromKey(req);
  if(!mesaId) return res.json({ok:false,error:"Mesa no autenticada"});
  const {dni, otp} = req.body||{};
  const voter = db.prepare("SELECT dni,name,course,otp,is_blocked, has_voted_rep,has_voted_amb,has_voted_per FROM voters WHERE dni=?").get(dni);
  if(!voter) return res.json({ok:false,error:"No encontrado"});
  if(voter.is_blocked) return res.json({ok:false,error:"Bloqueado, dirígete a coordinación"});
  if(String(otp)!==String(voter.otp)) return res.json({ok:false,error:"PIN incorrecto"});

  // Build races based on course
  const repCandidates = db.prepare("SELECT id,name,detail FROM candidates WHERE race='rep' AND course=?").all(voter.course);
  const ambCandidates = db.prepare("SELECT id,name,detail FROM candidates WHERE race='amb' AND course=?").all(voter.course);
  const perCandidates = db.prepare("SELECT id,name,detail FROM candidates WHERE race='per'").all();

  const races = {
    rep:{title:`Representante (${voter.course})`, candidates:repCandidates},
    amb:{title:`Líder Ambiental (${voter.course})`, candidates:ambCandidates},
    per:{title:`Personería (Colegio)`, candidates:perCandidates}
  };

  return res.json({ok:true, voter, races});
});

// Registrar voto. Guarda boleta anónima y marca como votado.
app.post("/api/vote/cast",(req,res)=>{
  const mesaId = getMesaIdFromKey(req);
  if(!mesaId) return res.json({ok:false,error:"Mesa no autenticada"});
  const {dni,otp,rep,amb,per} = req.body||{};
  const voter = db.prepare("SELECT * FROM voters WHERE dni=?").get(dni);
  if(!voter) return res.json({ok:false,error:"No encontrado"});
  if(String(otp)!==String(voter.otp)) return res.json({ok:false,error:"PIN incorrecto"});
  // prevent double vote per race
  if(voter.has_voted_rep && rep) return res.json({ok:false,error:"Ya votó representante"});
  if(voter.has_voted_amb && amb) return res.json({ok:false,error:"Ya votó líder ambiental"});
  if(voter.has_voted_per && per) return res.json({ok:false,error:"Ya votó personería"});

  const ballot_id = uuidv4();
  const now = new Date().toISOString();
  const races = [];
  const insertBallot = db.prepare("INSERT INTO ballots(ballot_id, mesa_id, race, candidate_id, created_at, audit_hash) VALUES(?,?,?,?,?,?)");

  function auditHash(payload){
    return bcrypt.hashSync(payload, 8).slice(-32);
  }

  if(rep){
    insertBallot.run(ballot_id, mesaId, "rep", rep, now, auditHash(`${dni}|rep|${now}`));
    db.prepare("UPDATE voters SET has_voted_rep=1 WHERE dni=?").run(dni);
    races.push("rep");
  }
  if(amb){
    insertBallot.run(ballot_id, mesaId, "amb", amb, now, auditHash(`${dni}|amb|${now}`));
    db.prepare("UPDATE voters SET has_voted_amb=1 WHERE dni=?").run(dni);
    races.push("amb");
  }
  if(per){
    insertBallot.run(ballot_id, mesaId, "per", per, now, auditHash(`${dni}|per|${now}`));
    db.prepare("UPDATE voters SET has_voted_per=1 WHERE dni=?").run(dni);
    races.push("per");
  }
  // rotate OTP so it can't be reused
  const newOtp = Math.floor(100000+Math.random()*900000);
  db.prepare("UPDATE voters SET otp=? WHERE dni=?").run(String(newOtp), dni);

  db.prepare("INSERT INTO ledger(ballot_id, mesa_id, timestamp, races, audit_hash) VALUES(?,?,?,?,?)").run(ballot_id, mesaId, now, races.join(","), bcrypt.hashSync(`${ballot_id}|${mesaId}`,8).slice(-32));
  return res.json({ok:true, receipt: ballot_id});
});

// Ledger visible por mesa (equipo)
app.get("/api/mesa/ledger",(req,res)=>{
  const mesaId = getMesaIdFromKey(req);
  if(!mesaId) return res.json({ok:false,error:"Mesa no autenticada"});
  const items = db.prepare("SELECT * FROM ledger WHERE mesa_id=? ORDER BY timestamp DESC LIMIT 100").all(mesaId)
   .map(r=>({ballot_id:r.ballot_id,timestamp:r.timestamp,races:r.races.split(","),audit_hash:r.audit_hash}));
  res.json({ok:true, items});
});

// Resultados admin
app.post("/api/admin/results",(req,res)=>{
  const {code} = req.body||{};
  const admin = db.prepare("SELECT code FROM admin WHERE code=?").get(code);
  if(!admin) return res.json({ok:false,error:"Código inválido"});

  const sumByRace = (race)=>db.prepare(`
    SELECT COALESCE(c.name,'Blanco') as name, COUNT(b.id) as count
    FROM ballots b LEFT JOIN candidates c ON b.candidate_id = c.id
    WHERE b.race = ?
    GROUP BY b.candidate_id
    ORDER BY count DESC
  `).all(race);

  const byMesa = db.prepare("SELECT mesa_id, COUNT(*) as votos FROM ballots GROUP BY mesa_id").all();
  res.json({ok:true, results:{rep:sumByRace("rep"),amb:sumByRace("amb"),per:sumByRace("per"),byMesa}});
});

const port = process.env.PORT || 3000;
app.listen(port, ()=>console.log("Servidor en http://localhost:"+port));
